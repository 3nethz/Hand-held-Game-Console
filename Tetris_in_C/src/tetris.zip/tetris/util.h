#ifndef UTIL_H
#define UTIL_H

void sleep_milli(int miliseconds);

#endif //UTIL_H